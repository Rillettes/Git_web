
   var code=prompt("Veuillez saisir le code:");
    if (code==LAMA79){
        alert("http://www-tp.it-sudparis.eu/~topin_ed/Images/space_lama.jpg")
    }
