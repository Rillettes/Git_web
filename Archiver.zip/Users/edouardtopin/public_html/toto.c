#include <stdlib.h>
#include<stdio.h>

int i;
for (i=0,i<100,i++){
  printf("%d",i);
 }
